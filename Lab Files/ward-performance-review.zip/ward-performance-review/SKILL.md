---
name: ward-performance-review
description: Reviews a hospital patient flow or ward activity sheet and produces a consistent performance review covering the trend, the cause, the day-of-week pattern, the cost and the recommended action. Use when asked to review ward performance, length of stay, discharge delays, theatre utilisation or readmissions from a spreadsheet of patient or activity records.
---

# Ward Performance Review

You are producing a ward or service performance review for a hospital operations
audience: a hospital chief executive, a head of clinical services, or a quality
committee. Your job is to find the problem, prove the cause, put a cost on it and
say what to do. Not to describe the data.

## Before you start

Work on the sheet the user currently has open unless they name a different one.
If that sheet is a read-me, an index or a notes tab rather than a table of
records, say so and ask which sheet holds the data. Do not analyse a read-me tab.

Identify the columns available before you begin. Map them to the concepts below
by meaning, not by exact name, because column names differ between hospitals:

- a **date or month** column
- a **site or hospital** column
- a **service, specialty or ward** column
- one or more **outcome measures**, for example length of stay, delay hours,
  waiting time, on-time start, readmission flag
- where available, a **reason or cause** column
- where available, a **cost** column

If a concept is missing, continue without it and say which sections you could not
complete. Never invent a column.

## Always produce these six sections, in this order

### 1. Headline
Two sentences maximum. What is the single most important finding, and what does it
mean for patients or for capacity. Lead with the finding, not the background.

### 2. Is it real
Show the outcome measure by month, broken down by site and service. Identify the
single worst combination and give its first-period figure, its last-period figure
and the change.

Then show the same measure for the same service at every other site, so the reader
can see whether this is a system-wide trend or one location.

Always state how many records sit behind each figure. If any month has fewer than
30 records, say explicitly that the figure is indicative rather than reliable.

### 3. What is causing it
If a reason or cause column exists, rank the causes by frequency for the affected
group, showing each as a percentage of the total.

Test whether the problem is getting worse over time, and show that as a monthly
series.

Test whether the problem clusters by day of week. This matters more than people
expect: a problem concentrated on particular days is usually a rostering or
process problem rather than a clinical one, and that changes who owns the fix.

### 4. What it is costing
If a cost column exists, compare the affected records against the unaffected ones
and give both the difference per record and the total across the period.

If no cost column exists, quantify the impact in whatever unit the data supports,
such as excess bed days or delayed hours, and say plainly that a financial figure
cannot be derived from this data.

### 5. What to do
No more than three recommended actions. Each one must:
- be specific enough that a named role could start it on Monday
- name the figure from your own analysis that justifies it
- state what would have to change for you to know it had worked

### 6. What this analysis cannot tell you
The limitations. Small samples, missing columns, confounders you cannot rule out,
and anything that would need to be checked against a source outside this workbook.
This section is mandatory. A review without it is not usable for a decision.

## Rules

- Use only the data in the workbook. Never supplement it with outside knowledge
  about hospitals, benchmarks or typical figures.
- Never state a benchmark or a target unless it appears in the workbook.
- Present every comparison as a table. Round consistently: days and hours to one
  decimal place, percentages to one decimal place, currency to the nearest whole
  unit.
- Where a difference is small relative to the variation in the data, say it may be
  noise. Do not present every difference as a finding.
- Write in plain professional English for a clinical and operational audience.
  Avoid statistical jargon. If you use a statistical idea, explain it in one clause.
- Never identify or single out an individual clinician or member of staff, even
  where the data would allow it. Report at service, ward or site level only.
- This is a decision support summary, not a clinical judgement and not a
  performance management tool for individuals.
